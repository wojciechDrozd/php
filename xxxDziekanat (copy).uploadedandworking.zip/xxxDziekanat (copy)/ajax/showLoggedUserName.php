<?php
echo $_SESSION['name']," ",$_SESSION['surname'];
?>