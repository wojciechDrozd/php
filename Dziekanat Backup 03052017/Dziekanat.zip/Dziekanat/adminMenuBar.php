<!-- pasek nawigacji dla panelu admina -->

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="adminPanel.php">Panel Administratora</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="studentsTable.php"">Studenci</a></li>
      <li><a href="teachersTable.php">Pracownicy</a></li>
      <li><a href="classesTable.php">Przedmioty</a></li>
      <li><a href="ajax/logout.php">Wyloguj</a></li>
    </ul>
  </div>
</nav>
