<?php


//ładowanie wszystkich studentów danego pracownika

session_start();

if (isset($_SESSION['pesel']) && $_SESSION['pesel'] != "" ){
	
	$teacher_pesel = $_SESSION['pesel'];
	
	require_once 'db_connection.php';

	// nagłówek tabeli studenci przypisani do danego pracownika
	$data = '<table class="table table-bordered table-striped">
                        <tr>
                            <th>Nr albumu</th>
							<th>Nazwisko</th>
                            <th>Imię</th>
                            <th>Kierunek studiów</th>
							<th>Semestr</th>
							<th>Email</th>
							<th>PESEL</th>
                        </tr>';
	
	
	$query = "SELECT nrAlbumu,studenci.imie,studenci.nazwisko,kierunek,semestr,studenci.email,studenci.pesel FROM 
	(((profesores INNER JOIN przedmioty ON profesores.idProfesores=przedmioty.Profesores_idProfesores)
	INNER JOIN studenci_has_przedmioty ON studenci_has_przedmioty.przedmioty_idprzedmiot_1=przedmioty.idprzedmiot)
	INNER JOIN studenci ON studenci_has_przedmioty.studenci_nr_albumu=studenci.nrAlbumu)
	WHERE profesores.pesel='$teacher_pesel' GROUP BY studenci.nazwisko ORDER BY studenci.nazwisko";
	
	$result = mysqli_query($con,$query);
	while($row = mysqli_fetch_assoc($result)){
	
		$data .= '<tr>
                <td>'.$row['nrAlbumu'].'</td>
                <td>'.$row['nazwisko'].'</td>
                <td>'.$row['imie'].'</td>
                <td>'.$row['kierunek'].'</td>
               	<td>'.$row['semestr'].'</td>
                <td>'.$row['email'].'</td>
                <td>'.$row['pesel'].'</td>
            </tr>';
	}
	
	
	$data .= '</table>';
	
	echo $data;
	
	
}
	
	
	
?>