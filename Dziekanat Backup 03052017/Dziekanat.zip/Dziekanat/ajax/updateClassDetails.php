<?php

//połączenie z bazą
require_once 'db_connection.php';


if (isset ( $_POST['class_id'] )) {
	
	$class_id = $_POST['class_id'];
	$class_name = $_POST ['class_name'];
	$teacher_full_name = $_POST ['teacher_full_name'];
	$exploded = explode(" ", $teacher_full_name);
	$teacher_surname = $exploded[0];
	$teacher_first_name = $exploded[1];
	
	//aktualizacja danych przedmiotu
	$query = "UPDATE przedmioty 
	SET nazwaPrzedmiotu = '$class_name',
	wykladowca = '$teacher_full_name',
	Profesores_idProfesores = 
	(SELECT idProfesores FROM profesores WHERE imie='$teacher_first_name' AND nazwisko='$teacher_surname')
	WHERE idprzedmiot='$class_id'"; 
	
	mysqli_query ( $con, $query ); 
}
?>