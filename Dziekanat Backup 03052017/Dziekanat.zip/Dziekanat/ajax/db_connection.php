<?php

//dane do połączenia z bazą (localhost)
$host = "localhost";  
$user = "root";  
$password = "";  
$database = "dziekanat";  

//dane do połączenia z bazą (hostinger)
/*  $host = "serwer1736136.home.pl";
 $user = "23999670_dziek";
 $password = "password1234";
 $database = "23999670_dziek";  */
               

//połączenie z bazą
try {
	$con = new mysqli ( $host, $user, $password, $database );
} catch ( Exception $e ) {
	"Connection failed: " . $con->connect_error;
}

?>