<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<script
	src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet"
	href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<script
	src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container" style="width: 500px;">

		<h3 align="center">Konto studenta</h3>
		<br />
		<form action="logout.php">
			
			<input type="submit" value="wyloguj" class="btn btn-info" /> <br />
		</form>
	</div>

</body>
</html>