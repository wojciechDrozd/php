<?php

//localhost connection
$host = "localhost";
$db_user="root";
$db_password="";
$db_name ="WirtualnaUczelnia";


//hostinger connection
/* $host = "mysql.hostinger.pl";
$db_user = "u465013593_szjz";
$db_password = "swinek14";
$db_name = "u465013593_users"; */